The docker image built here is intended for investigating delta issues, for example when they are OS-dependent.
