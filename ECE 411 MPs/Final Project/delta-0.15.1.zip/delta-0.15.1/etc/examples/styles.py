# avocet avocet avocet avocet
# bee-eater bee-eater bee-eater bee-eater
# chaffinch chaffinch chaffinch
# dodo dodo dodo dodo dodo
