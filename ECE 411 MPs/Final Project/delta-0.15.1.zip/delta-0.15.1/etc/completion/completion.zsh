compdef _gnu_generic delta
